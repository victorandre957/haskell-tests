module Trabalho_1 where
import Data.List (sortOn)

maior4 :: Int -> Int -> Int -> Int -> Int
maior4 a b c d = max a (max b (max c d))

converterNotaParaMencao :: Float -> String
converterNotaParaMencao nota
  | nota >= 9.0 = "SS"
  | nota >= 7.0 = "MS"
  | nota >= 5.0 = "MM"
  | nota >= 3.0 = "MI"
  | nota >= 0.1 = "II"
  | otherwise   = "SR"

isDecrescente :: [Int] -> Bool
isDecrescente [] = True
isDecrescente xs = all (>=0) $ zipWith (-) xs (tail xs)

histograma :: [String] -> [(String, Int)]
histograma [] = []
histograma (x:xs) =
  let count = 1 + length (filter (==x) xs)
  in (x, count) : histograma (filter (/=x) xs)

myZipWith :: (a -> b -> c) -> [a] -> [b] -> [c]
myZipWith f [] _ = []
myZipWith f _ [] = []
myZipWith f (x:xs) (y:ys) = f x y : myZipWith f xs ys

aprovadosOrdemDeMedia :: [(String,Float,Float)] -> [(String,Float)]
aprovadosOrdemDeMedia xs =
  sortOn snd [(nome, media) | (nome, nota1, nota2) <- xs,
  let media = (nota1 + nota2) / 2, media >= 5]

somaMatricial :: Num u => [[u]] -> [[u]] -> [[u]]
somaMatricial = zipWith (zipWith (+))

matrizTransposta :: Num u => [[u]] -> [[u]]
matrizTransposta ([]:_) = []
matrizTransposta x = map head x : matrizTransposta (map tail x)

multiplicacaoMatricial :: Num u => [[u]] -> [[u]] -> [[u]]
multiplicacaoMatricial a b = [[sum $ zipWith (*) ar bc | bc <- matrizTransposta b] | ar <- a]